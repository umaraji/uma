package com.pckg.model;

public class Phonenumber {

	private Integer id;
	private String phoneNumber;
	private User user;

	public Integer getId() {
		return id;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public User getUser() {
		return user;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
