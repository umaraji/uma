package com.pckg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.pckg.model.User;
import com.pckg.service.UserService;

public class Search extends AbstractController {

	private UserService user_Service;

	public void setUser_Service(UserService user_Service) {
		this.user_Service = user_Service;
	}

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String fn = request.getParameter("firstName");
		String ln = request.getParameter("lastName");
		String em = request.getParameter("emailid");
		String text = request.getParameter("search");

		String firstname = null;
		String lastname = null;
		String email = null;

		if (fn != null) {
			firstname = text;
		}
		if (ln != null) {
			lastname = text;
		}
		if (em != null) {
			email = text;
		}

		List<User> list = user_Service.SearchUser(email, firstname, lastname);

		return new ModelAndView("Search").addObject("userlist", list);
	}

}
