package com.pckg.service;

import java.util.Date;
import java.util.List;

import com.pckg.model.User;

public interface UserService {
	public void InsertUser(String firstname, String lastname, String email, String phone, Date date, String role);

	public List<User> SearchUser(String email, String firstname, String lastname);

	public void DeleteUser(int id);
	
	public void UpdateUser(int id,String firstName, String lastName,String email,String phonenumber, Date date, String role);
	
	public User SearchUserById(int id);
}
