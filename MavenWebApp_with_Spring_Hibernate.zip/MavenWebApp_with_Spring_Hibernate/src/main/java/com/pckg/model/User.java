package com.pckg.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class User {

	private Integer id;
	private String FirstName;
	private String LastName;
	private String email;
	private String PhoneNumber;
	private Date date;
	private String role;
	private Set<Phonenumber> phonenumbers = new HashSet<Phonenumber>();

	public User() {

	}

	public Date getDate() {
		return date;
	}

	public String getEmail() {
		return email;
	}

	public String getFirstName() {
		return FirstName;
	}

	public Integer getId() {
		return id;
	}

	public String getLastName() {
		return LastName;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public Set<Phonenumber> getPhonenumbers() {
		return phonenumbers;
	}

	public String getRole() {
		return role;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public void setPhonenumbers(Set<Phonenumber> phonenumbers) {
		this.phonenumbers = phonenumbers;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
