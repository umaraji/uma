package com.pckg.repository;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import com.pckg.model.User;

public class UserRepositoryImpl implements UserRepository {

	private SessionFactory sessionFactory;
	private User user;

	public void setUser(User user) {
		this.user = user;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void InsertUser(String firstname, String lastname, String email, String phone, Date date, String role) {
		try {
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			user.setDate(date);
			user.setEmail(email);
			user.setFirstName(firstname);
			user.setLastName(lastname);
			user.setPhoneNumber(phone);
			user.setRole(role);
			session.save(user);
			transaction.commit();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public List<User> SearchUser(String email, String firstname, String lastname) {
		Session session = sessionFactory.openSession();
		
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.or(Restrictions.like("email", email, MatchMode.ANYWHERE),Restrictions.or(Restrictions.like("FirstName", firstname, MatchMode.ANYWHERE),Restrictions.like("LastName", lastname, MatchMode.ANYWHERE))));
		List<User> users = criteria.list();
		return users;
	}

	public void DeleteUser(int id) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.eq("id", id));
		User user = (User) criteria.uniqueResult();
		session.delete(user);
		transaction.commit();
		session.close();
	}

	public void UpdateUser(int id, String firstName, String lastName, String email, String phonenumber, Date date,
			String role) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.eq("id", id));
		User user = (User) criteria.uniqueResult();
		user.setDate(date);
		user.setEmail(email);
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setPhoneNumber(phonenumber);
		user.setRole(role);
		session.update(user);
		transaction.commit();
		session.close();

	}

	public User SearchUserById(int id) {
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.eq("id", id));
		User user = (User) criteria.uniqueResult();

		return user;
	}

}
