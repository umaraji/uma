package com.pckg.service;

import java.util.Date;
import java.util.List;

import com.pckg.model.User;
import com.pckg.repository.UserRepository;

public class UserServiceImpl implements UserService {

	private UserRepository userRepository;

	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	public void InsertUser(String firstname, String lastname, String email, String phone, Date date, String role) {
		userRepository.InsertUser(firstname, lastname, email, phone, date, role);
	}

	public List<User> SearchUser(String email, String firstname, String lastname) {
		return userRepository.SearchUser(email, firstname, lastname);
	}

	public void DeleteUser(int id) {
		userRepository.DeleteUser(id);
	}

	public void UpdateUser(int id, String firstName, String lastName, String email, String phonenumber, Date date,
			String role) {
		userRepository.UpdateUser(id, firstName, lastName, email, phonenumber, date, role);

	}

	public User SearchUserById(int id) {
		return userRepository.SearchUserById(id);
	}

}
