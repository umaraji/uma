package com.pckg.controller;

import java.sql.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.pckg.service.UserService;

public class UpdateUser extends AbstractController {

	private UserService user_Service;

	public void setUser_Service(UserService user_Service) {
		this.user_Service = user_Service;
	}

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String id = request.getParameter("id");
		String firstname = request.getParameter("firstName");
		String lastname = request.getParameter("lastName");
		String email = request.getParameter("emailid");
		String phone = request.getParameter("phonenumber");
		String date = request.getParameter("date");
		String role = request.getParameter("role");
		Date date2 = Date.valueOf(date);

		user_Service.UpdateUser(Integer.parseInt(id), firstname, lastname, email, phone, date2, role);

		return new ModelAndView("Search");
	}

}
