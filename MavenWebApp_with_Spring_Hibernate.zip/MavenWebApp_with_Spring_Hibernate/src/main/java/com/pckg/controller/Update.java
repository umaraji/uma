package com.pckg.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.pckg.model.User;
import com.pckg.service.UserService;

public class Update extends AbstractController{

	private UserService user_Service;
	
	public void setUser_Service(UserService user_Service) {
		this.user_Service = user_Service;
	}

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse arg1) throws Exception {

		User user = user_Service.SearchUserById(Integer.parseInt(request.getParameter("id")));
		
		return new ModelAndView("Update").addObject("user", user);
	}

}
