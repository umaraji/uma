
CREATE TABLE IF NOT EXISTS user(
 
 `id` INT(11) NOT NULL AUTO_INCREMENT,

 `FirstName` VARCHAR(45) NULL DEFAULT NULL,
 
 `LastName` VARCHAR(45) NULL DEFAULT NULL,
  
 `email` VARCHAR(45) NULL DEFAULT NULL,
 
 `PhoneNumber` VARCHAR(10) NULL DEFAULT NULL,
 
 `date` DATE NULL DEFAULT NULL,
  
 `role` VARCHAR(45) NULL DEFAULT NULL,

  PRIMARY KEY (`id`))
;




CREATE TABLE IF NOT EXISTS phonenumber(

  `id` INT(11) NOT NULL AUTO_INCREMENT,
 
  `phoneNumber` VARCHAR(10) NULL DEFAULT NULL,
 
  `user_id` INT(11) NOT NULL,
 
   PRIMARY KEY (`id`),

  
   FOREIGN KEY (`user_id`)
   
   REFERENCES user(`id`)
);    
   